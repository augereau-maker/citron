// ============================================================================
// dashboard.js
// Charge et affiche les données du Dashboard Praticien : liste des patients,
// statistiques, plan du jour. N'importe aucune logique d'auth ou de forms.
// ============================================================================

import { supabase } from './supabase-client.js';

/** Charge les patients du praticien connecté. */
export async function loadPatients(practitionerId) {
  const { data, error } = await supabase
    .from('patients')
    .select('id, first_name, last_name, birth_date, created_at')
    .eq('practitioner_id', practitionerId)
    .order('last_name', { ascending: true });
  if (error) return { error: error.message };
  return { patients: data };
}

/** Charge les rendez-vous du jour pour le praticien connecté. */
export async function loadTodayAppointments(practitionerId) {
  const today = new Date().toISOString().slice(0, 10);
  const { data, error } = await supabase
    .from('appointments')
    .select('id, appointment_time, notes, status, patients(first_name, last_name)')
    .eq('practitioner_id', practitionerId)
    .eq('appointment_date', today)
    .order('appointment_time', { ascending: true });
  if (error) return { error: error.message };
  return { appointments: data };
}

/** Assemble les indicateurs affichés en haut du dashboard. */
export async function loadStats(practitionerId) {
  const [{ patients }, { appointments }] = await Promise.all([
    loadPatients(practitionerId),
    loadTodayAppointments(practitionerId),
  ]);

  const { count: formsCount } = await supabase
    .from('formulaires')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', practitionerId);

  return {
    totalPatients: patients?.length ?? 0,
    appointmentsToday: appointments?.length ?? 0,
    formsFilled: formsCount ?? 0,
  };
}

/** Rendu HTML de la liste de patients dans le conteneur donné. */
export function renderPatientList(container, patients) {
  if (!patients || patients.length === 0) {
    container.innerHTML = '<p class="empty-state">Aucun patient enregistré pour l’instant.</p>';
    return;
  }
  container.innerHTML = patients
    .map(
      (p) => `
      <li class="patient-row">
        <span class="patient-name">${escapeHtml(p.last_name)} ${escapeHtml(p.first_name)}</span>
        <span class="patient-meta">${p.birth_date ? formatDate(p.birth_date) : '—'}</span>
      </li>`
    )
    .join('');
}

/** Rendu HTML du plan du jour dans le conteneur donné. */
export function renderTodayPlan(container, appointments) {
  if (!appointments || appointments.length === 0) {
    container.innerHTML = '<p class="empty-state">Aucun rendez-vous prévu aujourd’hui.</p>';
    return;
  }
  container.innerHTML = appointments
    .map((a) => {
      const patientName = a.patients ? `${a.patients.first_name} ${a.patients.last_name}` : 'Patient';
      return `
      <li class="appointment-row">
        <span class="appointment-time">${escapeHtml(a.appointment_time?.slice(0, 5) || '')}</span>
        <span class="appointment-patient">${escapeHtml(patientName)}</span>
        <span class="appointment-status status-${escapeHtml(a.status || 'prevu')}">${escapeHtml(a.status || 'prévu')}</span>
      </li>`;
    })
    .join('');
}

function formatDate(isoDate) {
  return new Date(isoDate).toLocaleDateString('fr-FR');
}

function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  }[c]));
}
