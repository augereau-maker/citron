// ============================================================================
// app.js
// Point d'entrée. Ne contient pas de logique métier : il orchestre les
// modules (navigation, auth, dashboard, forms) et branche les événements DOM.
// ============================================================================

import { supabase } from './supabase-client.js';
import { showScreen, goToAuth } from './navigation.js';
import { signIn, signUp, signOut, getSession, getProfile } from './auth.js';
import { loadPatients, loadTodayAppointments, loadStats, renderPatientList, renderTodayPlan } from './dashboard.js';
import { submitDynamicForm } from './forms.js';

let currentUser = null;
let currentProfile = null;

// ---------------------------------------------------------------------------
// Démarrage : vérifie s'il existe déjà une session active
// ---------------------------------------------------------------------------
async function init() {
  const session = await getSession();
  if (session) {
    await enterApp(session.user);
  } else {
    showScreen('landing');
  }

  bindLandingEvents();
  bindAuthEvents();
  bindDashboardEvents();
}

/** Charge le profil puis affiche le dashboard adapté au rôle. */
async function enterApp(user) {
  currentUser = user;
  const { profile, error } = await getProfile(user.id);
  if (error) {
    console.error('Impossible de charger le profil :', error);
  }
  currentProfile = profile || { role: 'praticien', full_name: user.email };

  document.getElementById('dashboard-user-name').textContent = currentProfile.full_name || user.email;
  document.getElementById('dashboard-user-role').textContent =
    currentProfile.role === 'praticien' ? 'Espace praticien' : 'Espace patient';

  showScreen('dashboard');
  await refreshDashboardData();
}

async function refreshDashboardData() {
  if (!currentUser) return;
  const [{ patients }, { appointments }, stats] = await Promise.all([
    loadPatients(currentUser.id),
    loadTodayAppointments(currentUser.id),
    loadStats(currentUser.id),
  ]);

  renderPatientList(document.getElementById('patient-list'), patients);
  renderTodayPlan(document.getElementById('today-plan'), appointments);

  document.getElementById('stat-patients').textContent = stats.totalPatients;
  document.getElementById('stat-appointments').textContent = stats.appointmentsToday;
  document.getElementById('stat-forms').textContent = stats.formsFilled;
}

// ---------------------------------------------------------------------------
// Écran 1 : Landing
// ---------------------------------------------------------------------------
function bindLandingEvents() {
  document.getElementById('btn-espace-praticien').addEventListener('click', () => goToAuth('login', 'praticien'));
  document.getElementById('btn-espace-patient').addEventListener('click', () => goToAuth('login', 'patient'));
}

// ---------------------------------------------------------------------------
// Écran 2 : Auth (connexion / inscription)
// ---------------------------------------------------------------------------
function bindAuthEvents() {
  document.getElementById('btn-back-to-landing').addEventListener('click', () => showScreen('landing'));

  document.querySelectorAll('.auth-tab').forEach((tab) => {
    tab.addEventListener('click', () => goToAuth(tab.dataset.mode, document.getElementById('signup-role').value));
  });

  const loginForm = document.getElementById('form-login');
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = loginForm.email.value.trim();
    const password = loginForm.password.value;
    const errorEl = document.getElementById('login-error');
    errorEl.textContent = '';

    const result = await signIn(email, password);
    if (result.error) {
      errorEl.textContent = result.error;
      return;
    }
    loginForm.reset();
    await enterApp(result.user);
  });

  const signupForm = document.getElementById('form-signup');
  signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorEl = document.getElementById('signup-error');
    errorEl.textContent = '';

    const result = await signUp({
      email: signupForm.email.value.trim(),
      password: signupForm.password.value,
      fullName: signupForm.fullName.value.trim(),
      role: signupForm.role.value,
    });

    if (result.error) {
      errorEl.textContent = result.error;
      return;
    }

    if (result.user && result.user.confirmed_at === null) {
      errorEl.textContent = '';
      document.getElementById('signup-success').hidden = false;
      signupForm.reset();
      return;
    }

    signupForm.reset();
    await enterApp(result.user);
  });
}

// ---------------------------------------------------------------------------
// Écran 3 : Dashboard
// ---------------------------------------------------------------------------
function bindDashboardEvents() {
  document.getElementById('btn-logout').addEventListener('click', async () => {
    await signOut();
    currentUser = null;
    currentProfile = null;
    showScreen('landing');
  });

  const anamneseForm = document.getElementById('form-anamnese');
  if (anamneseForm) {
    anamneseForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!currentUser) return;
      const result = await submitDynamicForm(anamneseForm, 'anamnese', currentUser.id);
      const feedback = document.getElementById('anamnese-feedback');
      if (result.success) {
        feedback.textContent = `${result.label} enregistrée avec succès.`;
        feedback.className = 'form-feedback is-success';
        await refreshDashboardData();
      } else {
        feedback.textContent = '';
      }
    });
  }
}

// ---------------------------------------------------------------------------
// Réagit aussi aux changements de session déclenchés ailleurs (autre onglet…)
// ---------------------------------------------------------------------------
supabase.auth.onAuthStateChange((event) => {
  if (event === 'SIGNED_OUT') {
    currentUser = null;
    currentProfile = null;
    showScreen('landing');
  }
});

init();
