// ============================================================================
// supabase-client.js
// Seul fichier responsable de la connexion à Supabase.
// Aucune logique métier ici : uniquement l'initialisation du client.
// Tous les autres modules importent `supabase` depuis ce fichier.
// ============================================================================

import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

// ⚠️ À REMPLACER par les identifiants de VOTRE projet Supabase
// (Dashboard Supabase → Project Settings → API)
const SUPABASE_URL = 'https://VOTRE-PROJET.supabase.co';
const SUPABASE_ANON_KEY = 'VOTRE_CLE_ANON_PUBLIQUE';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
