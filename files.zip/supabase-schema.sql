-- ============================================================================
-- CITRON — Script SQL Supabase
-- À exécuter dans : Dashboard Supabase → SQL Editor → New query
-- Peut être exécuté plusieurs fois sans erreur (IF NOT EXISTS / DROP POLICY).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. Table PROFILES (rôle praticien / patient, liée à auth.users)
-- ----------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null check (role in ('praticien', 'patient')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "profiles: chacun voit son propre profil" on public.profiles;
create policy "profiles: chacun voit son propre profil"
  on public.profiles for select
  using (auth.uid() = id);

drop policy if exists "profiles: chacun crée son propre profil" on public.profiles;
create policy "profiles: chacun crée son propre profil"
  on public.profiles for insert
  with check (auth.uid() = id);

drop policy if exists "profiles: chacun modifie son propre profil" on public.profiles;
create policy "profiles: chacun modifie son propre profil"
  on public.profiles for update
  using (auth.uid() = id);


-- ----------------------------------------------------------------------------
-- 2. Table PATIENTS (fiches patients créées par un praticien)
-- ----------------------------------------------------------------------------
create table if not exists public.patients (
  id uuid primary key default gen_random_uuid(),
  practitioner_id uuid not null references auth.users(id) on delete cascade,
  first_name text not null,
  last_name text not null,
  birth_date date,
  created_at timestamptz not null default now()
);

alter table public.patients enable row level security;

drop policy if exists "patients: le praticien gère ses patients" on public.patients;
create policy "patients: le praticien gère ses patients"
  on public.patients for all
  using (auth.uid() = practitioner_id)
  with check (auth.uid() = practitioner_id);


-- ----------------------------------------------------------------------------
-- 3. Table APPOINTMENTS (rendez-vous, pour le "plan du jour")
-- ----------------------------------------------------------------------------
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  practitioner_id uuid not null references auth.users(id) on delete cascade,
  patient_id uuid references public.patients(id) on delete set null,
  appointment_date date not null,
  appointment_time time not null,
  status text not null default 'prevu' check (status in ('prevu', 'confirme', 'annule', 'termine')),
  notes text,
  created_at timestamptz not null default now()
);

alter table public.appointments enable row level security;

drop policy if exists "appointments: le praticien gère ses rendez-vous" on public.appointments;
create policy "appointments: le praticien gère ses rendez-vous"
  on public.appointments for all
  using (auth.uid() = practitioner_id)
  with check (auth.uid() = practitioner_id);


-- ----------------------------------------------------------------------------
-- 4. Table FORMULAIRES (formulaires dynamiques en JSONB)
-- ----------------------------------------------------------------------------
create table if not exists public.formulaires (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  patient_id uuid references public.patients(id) on delete set null,
  form_type text not null,
  form_data jsonb not null,
  created_at timestamptz not null default now()
);

-- Index pour interroger rapidement le contenu JSONB si besoin plus tard
create index if not exists formulaires_form_data_gin on public.formulaires using gin (form_data);
create index if not exists formulaires_user_id_idx on public.formulaires (user_id);

alter table public.formulaires enable row level security;

drop policy if exists "formulaires: l'auteur gère ses formulaires" on public.formulaires;
create policy "formulaires: l'auteur gère ses formulaires"
  on public.formulaires for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);


-- ----------------------------------------------------------------------------
-- 5. (Optionnel mais recommandé) Trigger de sécurité :
--    empêche un compte de s'auto-attribuer un rôle différent après création.
--    La création du profil se fait déjà côté application (voir auth.js) ;
--    ce trigger est un filet de sécurité si l'insertion applicative échoue.
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.email),
    coalesce(new.raw_user_meta_data->>'role', 'praticien')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Fin du script.
