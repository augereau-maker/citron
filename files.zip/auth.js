// ============================================================================
// auth.js
// Toute la logique Supabase Auth : connexion, inscription, déconnexion,
// récupération du profil (rôle praticien / patient).
// ============================================================================

import { supabase } from './supabase-client.js';

/**
 * Connecte un utilisateur existant.
 * @returns {{user: object}|{error: string}}
 */
export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { error: translateAuthError(error) };
  return { user: data.user };
}

/**
 * Crée un compte, puis crée la ligne de profil associée (rôle + nom).
 * @returns {{user: object}|{error: string}}
 */
export async function signUp({ email, password, fullName, role }) {
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) return { error: translateAuthError(error) };

  const user = data.user;
  // Si la confirmation par e-mail est activée, `user` existe mais la session
  // n'est pas encore active : on tente quand même de créer le profil,
  // Supabase acceptera l'insertion grâce à la policy "insert own profile".
  if (user) {
    const { error: profileError } = await supabase
      .from('profiles')
      .insert({ id: user.id, full_name: fullName, role });
    if (profileError) {
      return { error: `Compte créé, mais le profil n'a pas pu être enregistré : ${profileError.message}` };
    }
  }

  return { user };
}

/** Déconnecte l'utilisateur courant. */
export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) return { error: error.message };
  return { success: true };
}

/** Retourne la session active (ou null). */
export async function getSession() {
  const { data } = await supabase.auth.getSession();
  return data.session;
}

/** Récupère le profil (rôle, nom) de l'utilisateur courant. */
export async function getProfile(userId) {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, role')
    .eq('id', userId)
    .single();
  if (error) return { error: error.message };
  return { profile: data };
}

/** Traduit les messages d'erreur Supabase les plus courants en français. */
function translateAuthError(error) {
  const msg = error.message || '';
  if (msg.includes('Invalid login credentials')) return 'E-mail ou mot de passe incorrect.';
  if (msg.includes('User already registered')) return 'Un compte existe déjà avec cet e-mail.';
  if (msg.includes('Password should be at least')) return 'Le mot de passe doit contenir au moins 6 caractères.';
  if (msg.includes('Email not confirmed')) return 'Merci de confirmer votre e-mail avant de vous connecter.';
  return msg || 'Une erreur est survenue, merci de réessayer.';
}
