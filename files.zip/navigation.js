// ============================================================================
// navigation.js
// Gère uniquement la bascule entre les écrans (Landing / Auth / Dashboard).
// Ne contient aucune logique Supabase : reçoit des données déjà prêtes.
// ============================================================================

const screens = {
  landing: document.getElementById('screen-landing'),
  auth: document.getElementById('screen-auth'),
  dashboard: document.getElementById('screen-dashboard'),
};

/**
 * Affiche un écran et masque les autres.
 * @param {'landing'|'auth'|'dashboard'} name
 */
export function showScreen(name) {
  Object.entries(screens).forEach(([key, el]) => {
    if (!el) return;
    el.hidden = key !== name;
  });
  window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
}

/**
 * Pré-sélectionne l'onglet Connexion/Inscription et le profil visé
 * avant d'afficher l'écran d'authentification.
 * @param {'login'|'signup'} mode
 * @param {'praticien'|'patient'} role
 */
export function goToAuth(mode = 'login', role = 'praticien') {
  document.querySelectorAll('.auth-tab').forEach((tab) => {
    tab.classList.toggle('is-active', tab.dataset.mode === mode);
  });
  document.querySelectorAll('.auth-form').forEach((form) => {
    form.hidden = form.dataset.mode !== mode;
  });
  const roleField = document.getElementById('signup-role');
  if (roleField) roleField.value = role;

  const intro = document.getElementById('auth-intro');
  if (intro) {
    intro.textContent =
      role === 'praticien'
        ? 'Connectez-vous à votre espace professionnel CITRON.'
        : 'Connectez-vous à votre espace de suivi CITRON.';
  }

  showScreen('auth');
}
